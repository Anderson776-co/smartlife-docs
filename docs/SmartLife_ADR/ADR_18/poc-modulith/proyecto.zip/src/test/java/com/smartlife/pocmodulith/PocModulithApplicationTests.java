package com.smartlife.pocmodulith;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PocModulithApplicationTests {

	@Test
	void contextLoads() {
	}

}
